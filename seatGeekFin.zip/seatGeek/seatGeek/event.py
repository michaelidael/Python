from flask import Flask, render_template, request
from flask_wtf import FlaskForm
import requests
from wtforms import StringField, SubmitField, SelectField, RadioField, validators
import os
import json
import main_functions

app = Flask(__name__, template_folder='template')
app.config['SECRET_KEY'] = os.urandom(24)


class evForm(FlaskForm):
    eventSearch = RadioField("Type", choices=[("Music"), ("Sports"), ("Other")])
    parameter = SelectField("State", choices=[("AL"),
                                              ("AK"),
                                              ("AZ"),
                                              ("AR"),
                                              ("CO"),
                                              ("CA"),
                                              ("CT"),
                                              ("DE"),
                                              ("DC"),
                                              ("FL"),
                                              ("GA"),
                                              ("HI"),
                                              ("ID"),
                                              ("IL"),
                                              ("IN"),
                                              ("IA"),
                                              ("KS"),
                                              ("KY"),
                                              ("LA"),
                                              ("ME"),
                                              ("MD"),
                                              ("MA"),
                                              ("MI"),
                                              ("MN"),
                                              ("MS"),
                                              ("MO"),
                                              ("MT"),
                                              ("NE"),
                                              ("NV"),
                                              ("NH"),
                                              ("NJ"),
                                              ("NM"),
                                              ("NY"),
                                              ("NC"),
                                              ("ND"),
                                              ("OH"),
                                              ("OK"),
                                              ("OR"),
                                              ("PA"),
                                              ("RI"),
                                              ("SC"),
                                              ("SD"),
                                              ("TN"),
                                              ("TX"),
                                              ("UT"),
                                              ("VT"),
                                              ("VA"),
                                              ("WA"),
                                              ("WI"),
                                              ("WY"),
                                              ("BC"),
                                              ("ON")])
    name = StringField('Name', [validators.DataRequired()])

    submit = SubmitField('Submit')


def get_api_key(filename):
    my_aqi_api_key = main_functions.read_from_file(filename)["aqi_key"]
    print(my_aqi_api_key)
    return str(my_aqi_api_key)


my_aqi_api_key = get_api_key("api_keys.json")


def get_aqi_data(my_aqi_api_key, parameter):
    # url = " https://api.seatgeek.com/2/events?client_id="
    # url_aqi = url + my_aqi_api_key
    # response = requests.get(url_aqi).json()
    # print(url_aqi)
    # request_api = main_functions.read_from_file("api_keys.json")
    # main_functions.save_to_file(response, "saved.json")
    global j
    url = f"https://api.seatgeek.com/2/events?client_id={my_aqi_api_key}"
    response = requests.get(url).json()
    main_functions.save_to_file(response, "saved.json")
    # print(response["events"])
    # print(response["events"][1]["type"])
    # print(response["events"][2]["datetime_utc"])
    # print(response["events"][2]["venue"]["state"])
    # print(type(response["events"][0]))
    # print(type(response["events"]))
    url = []
    information = []
    locations = []

    # could make a for loop on the url to tell user what is available
    # could make a for loop on the type of event

    for i in response["events"]:
        location = i["venue"]["state"]
        print(location)
        print(i["type"])
        print(i["venue"]["url"])
        url.append(i["venue"]["url"])
        information.append(i["type"])
        locations.append(i["venue"]["state"])
    print(url)
    print(information)
    print(locations)

    all_list = []

    # previous lists for testing the lists ability to transfer
    # all_links = []
    # all_tickets = []
    # all_desc = []
    # all_places = []
    for j in response['events']:

        if j["venue"]["state"] == parameter:
            print(j["venue"]["url"])
            link = j["venue"]["url"]
            # all_links.append(link)
            all_list.append(link)

            #print(j["type"])
            ticket_type = j["type"]
            # all_tickets.append(ticket_type)
            all_list.append(ticket_type)

            #print(j["short_title"])
            shortdesc = j["short_title"]
            # all_desc.append(shortdesc)
            all_list.append(shortdesc)

            place = j["venue"]["city"] + " " + j["venue"]["state"] + " -------"
            #print(place)
            all_list.append(place)

            #print(j["performers"][0]["image"])
            pic = j["performers"][0]["image"]
            all_list.append(pic)

            # print(j["performers"]["image"])
            # pic = j["performers"]["image"]
            # print(pic)
            # all_list.append(pic)




        # this for loop was for printing out each event but it did not work
        # for i in all_places,all_desc,all_links:
        #     print(i)
        #     all_data = i
        else:
            print("none")

    #if j["venue"]["state"] != parameter:
        #all_list.append("nothing follows")

    #print(all_list)

    return {
        "data": all_list,
        "locations": locations,
        #   "icon_description": icon_description[icon].title(),
        "parameter": parameter}


# get_aqi_data(my_aqi_api_key)


@app.route('/', methods=['GET', 'POST'])
def index():
    form = evForm()

    # TODO: assign the form created above into a variable into a variable named form
    if request.method == "POST":
        search_entered = form.eventSearch.data
        parameter_entered = form.parameter.data
        name_entered = form.name.data

        all_data = get_aqi_data(my_aqi_api_key, parameter_entered)
        print(all_data)
        print("above is all data")
        # this is a dictionary type
        first_part = all_data['data'][0]
        U_rl = all_data['data'][0]
        type_of_event = all_data['data'][1]
        short_desc = all_data['data'][2]
        place_of_event = all_data['data'][3]
        imagelink = all_data['data'][4]
        # this is a list of the event information
        availableLoc_part = all_data['locations']
        print(availableLoc_part)
        # this is the available locations
        # this_img = all_data['icon']
        from_thisState = all_data['parameter']
        # this is where the user is from, or the selected state
        print(first_part)
        print(from_thisState)
        print(type(all_data))
        sent_data = [first_part, availableLoc_part, from_thisState, search_entered, name_entered, parameter_entered,
                     imagelink, U_rl, type_of_event, short_desc, place_of_event]
        print(sent_data)
        print(type(sent_data))

        return render_template("ev_results.html", data=sent_data)
        # TODO: return render_template passing the correct html document, and the correct parameters
    parameter_entered = form.parameter.data
    all_data = get_aqi_data(my_aqi_api_key, parameter_entered)

    return render_template('ev.html', form=form, data=all_data)
    # return render_template('ev.html', data=all_data)
    # TODO: return render_template passing the correct html document, and the correct form parameter


if __name__ == '__main__':
    app.run(debug=True)
